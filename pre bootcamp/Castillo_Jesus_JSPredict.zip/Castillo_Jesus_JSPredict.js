predict 1 // undefined
predict 2 // 1980
predict 3 // 30